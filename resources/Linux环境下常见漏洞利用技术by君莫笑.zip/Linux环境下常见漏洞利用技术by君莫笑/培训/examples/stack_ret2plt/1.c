#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void ShowInfo(char *name);
void UsePrinter(void);
void ShowList(void);

int main()
{
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
    fflush(stdout);

    char name[256] = {"\x00"};
    int choice;

    printf("Welcome to use the OA system.\n");
    printf("input your name:");
    scanf("%256s", name);
    while(1)
    {
        printf("what do you want to do?\n");
        printf("1 Show the information\n");
        printf("2 Use the printer\n");
        printf("3 show the todo list\n");
        printf("4 exit\n:");
        scanf("%d", &choice);
        switch(choice){
            case 1:
                ShowInfo(name);
                break;
            case 2:
                UsePrinter();
                break;
            case 3:
                ShowList();
                break;
            default:
                exit(0);

        }
    }

}

void ShowList(void)
{
    printf("nothing to do!\n");
}

void ShowInfo(char *name)
{
    char newName[128] = {"\x00"};
    strcpy(newName, name);
    printf("your name:%s\n", newName);
}

void UsePrinter(void)
{
    system("echo you are usring the printer");
}
