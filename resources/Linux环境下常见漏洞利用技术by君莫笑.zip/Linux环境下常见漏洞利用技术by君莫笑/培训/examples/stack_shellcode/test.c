#include <stdio.h>
#include <unistd.h>
#include <string.h>

void deal_user_info(char* name)
{
    char dealed_name[100];
    memcpy(dealed_name, name, 200);
}

int main()
{
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    
    char name[200];
    
    puts("welcome\n");
    read(STDIN_FILENO, name, 200);
    deal_user_info(name);
    printf("bye\n");
}
